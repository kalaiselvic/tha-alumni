require 'rubygems'
require 'bundler'
require 'nokogiri'
require 'htmlentities'
require 'pry'
require 'json'

require_relative 'helpers/i18n_helper'
require_relative 'helpers/html_helper'

Bundler.require(:test)
